import become_our_Dealer1 from  './become_our_Dealer1.jpg'

export const asset = {
    become_our_Dealer1
}