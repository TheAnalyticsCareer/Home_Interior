import contact_us_banner from './OIP.jfif'
import phone from './phone.png'
import email from './email.png'
import location from './location.png'



export  const assets = {
    contact_us_banner,
    phone,
    email,
    location
}